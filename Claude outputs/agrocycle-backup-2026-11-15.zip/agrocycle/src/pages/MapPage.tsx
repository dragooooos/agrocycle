import "./MapPage.css";
import {
  BarChart3,
  Bug,
  Coins,
  CloudRain,
  CloudRainWind,
  CloudSun,
  Droplet,
  Droplets,
  Flame,
  Haze,
  Leaf,
  MapPin,
  Mountain,
  MousePointerClick,
  Search,
  Snowflake,
  Sprout,
  Square,
  Shovel,
  Thermometer,
  ThermometerSun,
  Tractor,
  TrendingDown,
  X,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import MapView from "../components/MapView";
import type { AreaUnit, FarmerConstraints, FieldSelection, IndicatorId, PriorityId } from "../types";
import { CROP_BY_ID, SELECTABLE_CROPS } from "../data/crops";
import { readIndicators } from "../data/layers";
import { getSourceState, startSource } from "../services/sourceStore";
import { readSelection, saveSelection } from "../services/selection";

const readConstraints = (): FarmerConstraints => {
  try {
    const raw = sessionStorage.getItem("farmrotate:constraints");
    if (raw) return { irrigation: false, livestock: false, currentCrops: [], ...JSON.parse(raw) };
  } catch {
    // ignore
  }
  return { irrigation: false, livestock: false, currentCrops: [] };
};

/** Saved priorities for this tab, keeping only known ones. */
const readPriorities = (): PriorityId[] => {
  try {
    const raw = sessionStorage.getItem("farmrotate:priorities");
    const parsed: unknown = raw ? JSON.parse(raw) : null;
    if (Array.isArray(parsed)) {
      return parsed.filter((id): id is PriorityId => priorityOptions.some((option) => option.id === id));
    }
  } catch {
    // ignore: fall back to the defaults
  }
  return ["water", "soil"];
};

const saveJson = (key: string, value: unknown) => {
  try {
    sessionStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage unavailable: the choice still works on this page.
  }
};

const priorityOptions: {
  id: PriorityId;
  label: string;
  icon: typeof Droplets;
}[] = [
  { id: "water", label: "Save water", icon: Droplets },
  { id: "soil", label: "Build soil health", icon: Sprout },
  { id: "heat", label: "Handle heat", icon: Flame },
  { id: "erosion", label: "Protect soil", icon: Mountain },
  { id: "pest", label: "Break pest cycles", icon: Bug },
  { id: "income", label: "Protect income", icon: Coins },
];

const indicatorOptions: {
  id: IndicatorId;
  label: string;
  icon: typeof Droplets;
}[] = [
  { id: "temperature", label: "Temperature", icon: Thermometer },
  { id: "heatStress", label: "Heat stress", icon: ThermometerSun },
  { id: "rainfall", label: "Rainfall", icon: CloudRain },
  { id: "soilMoisture", label: "Soil moisture", icon: Droplet },
  { id: "evaporation", label: "Evaporation", icon: Haze },
  { id: "frostRisk", label: "Frost risk", icon: Snowflake },
  { id: "extremePrecipitation", label: "Extreme precipitation", icon: CloudRainWind },
  { id: "vegetationStress", label: "Vegetation stress", icon: Leaf },
  { id: "waterTrends", label: "Long-term water trends", icon: TrendingDown },
  { id: "slopeErosion", label: "Slope & erosion", icon: Mountain },
  { id: "soilProperties", label: "Soil properties", icon: Shovel },
];

const unitLabels: Record<AreaUnit, string> = {
  m2: "m²",
  ha: "ha",
  km2: "km²",
  acres: "acres",
  ft2: "ft²",
};

function convertArea(squareMeters: number, unit: AreaUnit) {
  if (unit === "ha") return squareMeters / 10_000;
  if (unit === "km2") return squareMeters / 1_000_000;
  if (unit === "acres") return squareMeters / 4046.8564224;
  if (unit === "ft2") return squareMeters * 10.7639104167;
  return squareMeters;
}

type PanelId = "location" | "priorities" | "indicators" | "farm";

export default function MapPage() {
  const navigate = useNavigate();
  // The selection survives a trip to the analysis page and back (see services/selection.ts).
  const [field, setField] = useState<FieldSelection | null>(readSelection);
  const [initialSelection] = useState(field);
  const clearSelection = useCallback(() => setField(null), []);

  useEffect(() => {
    saveSelection(field);
  }, [field]);
  const [showContinueHint, setShowContinueHint] = useState(false);

  // The first time someone selects a location, point at the continue button once.
  useEffect(() => {
    if (!field) return;
    const key = "agrocycle:continue-hint-seen";
    try {
      if (localStorage.getItem(key)) return;
      localStorage.setItem(key, "1");
    } catch {
      return; // storage unavailable: skip the hint rather than repeat it every time
    }
    setShowContinueHint(true);
    const timer = setTimeout(() => setShowContinueHint(false), 7000);
    return () => clearTimeout(timer);
  }, [field]);
  const [unit] = useState<AreaUnit>("ha");
  const [priorities, setPriorities] = useState<PriorityId[]>(readPriorities);

  const [locationSlot, setLocationSlot] = useState<HTMLDivElement | null>(null);
  const [openPanel, setOpenPanel] = useState<PanelId | null>("location");

  const togglePanel = (panel: PanelId) => {
    setOpenPanel((current) => (current === panel ? null : panel));
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpenPanel(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const [indicators, setIndicators] = useState<IndicatorId[]>(readIndicators);

  // Start the soil lookup as soon as a point is chosen; the analysis page reuses this result.
  useEffect(() => {
    if (!field) return;
    // The restored selection from before the analysis page: don't ask again for a
    // soil check that already failed there (Retry on the analysis page does that).
    if (field === initialSelection && getSourceState("soil", field.latitude, field.longitude).status === "error") return;
    startSource("soil", field.latitude, field.longitude);
  }, [field, initialSelection]);
  const [constraints, setConstraints] = useState<FarmerConstraints>(readConstraints);

  // Keep the panel choices too, so the whole map page comes back as it was left.
  useEffect(() => saveJson("farmrotate:priorities", priorities), [priorities]);
  useEffect(() => saveJson("farmrotate:indicators", indicators), [indicators]);
  useEffect(() => saveJson("farmrotate:constraints", constraints), [constraints]);

  const addCrop = (id: string) => {
    if (!id) return;
    setConstraints((current) =>
      current.currentCrops.length >= 4 ? current : { ...current, currentCrops: [...current.currentCrops, id] },
    );
  };

  const removeCrop = (index: number) =>
    setConstraints((current) => ({
      ...current,
      currentCrops: current.currentCrops.filter((_, i) => i !== index),
    }));

  const toggleIndicator = (id: IndicatorId) => {
    setIndicators((current) =>
      current.includes(id)
        ? current.filter((value) => value !== id)
        : [...current, id],
    );
  };

  const togglePriority = (id: PriorityId) => {
    setPriorities((current) =>
      current.includes(id)
        ? current.filter((value) => value !== id)
        : [...current, id],
    );
  };

  const displayArea =
    field?.selectionType === "area"
      ? `${convertArea(field.area, unit).toLocaleString(undefined, {
          maximumFractionDigits: 2,
        })} ${unitLabels[unit]}`
      : null;

  const analyze = () => {
    if (!field) return;

    saveSelection({ ...field, areaUnit: unit });
    try {
      sessionStorage.setItem("farmrotate:note", ""); // plain text, read as-is by the analysis page
    } catch {
      // ignore
    }
    navigate("/analysis");
  };

  return (
    <div className="map-page-shell">
      <main className="map-page">
        <MapView
          onFieldSelected={setField}
          onSelectionCleared={clearSelection}
          initialSelection={initialSelection}
          coordinatesContainer={locationSlot}
        />

        <div className="map-island-dock">
          {openPanel === "location" && (
            <section
              id="island-panel-location"
              className="island-panel"
              role="dialog"
              aria-label="Find a location"
            >
              <div className="island-panel-header">
                <div>
                  <span className="eyebrow">Navigate</span>
                </div>
                <button
                  className="island-close"
                  onClick={() => setOpenPanel(null)}
                  aria-label="Close panel"
                >
                  <X size={16} />
                </button>
              </div>
              <div ref={setLocationSlot} />
            </section>
          )}

          {openPanel === "priorities" && (
            <section
              id="island-panel-priorities"
              className="island-panel"
              role="dialog"
              aria-label="Farmer priorities"
            >
              <div className="island-panel-header">
                <div>
                  <span className="eyebrow">Farmer priorities</span>
                </div>
                <button
                  className="island-close"
                  onClick={() => setOpenPanel(null)}
                  aria-label="Close panel"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="priority-mini-grid">
                {priorityOptions.map(({ id, label, icon: Icon }) => {
                  const active = priorities.includes(id);
                  return (
                    <button
                      key={id}
                      className={active ? "mini-priority active" : "mini-priority"}
                      onClick={() => togglePriority(id)}
                      aria-pressed={active}
                    >
                      <Icon size={16} />
                      {label}
                    </button>
                  );
                })}
              </div>
            </section>
          )}

          {openPanel === "indicators" && (
            <section
              id="island-panel-indicators"
              className="island-panel"
              role="dialog"
              aria-label="Climate indicators"
            >
              <div className="island-panel-header">
                <div>
                  <span className="eyebrow">Climate indicators</span>
                </div>
                <button
                  className="island-close"
                  onClick={() => setOpenPanel(null)}
                  aria-label="Close panel"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="indicator-actions">
                <button onClick={() => setIndicators(indicatorOptions.map((option) => option.id))}>
                  Select all
                </button>
                <button onClick={() => setIndicators([])}>Clear</button>
              </div>

              <div className="priority-mini-grid">
                {indicatorOptions.map(({ id, label, icon: Icon }) => {
                  const active = indicators.includes(id);
                  return (
                    <button
                      key={id}
                      className={active ? "mini-priority active" : "mini-priority"}
                      onClick={() => toggleIndicator(id)}
                      aria-pressed={active}
                    >
                      <Icon size={16} />
                      {label}
                    </button>
                  );
                })}
              </div>
            </section>
          )}

          {openPanel === "farm" && (
            <section
              id="island-panel-farm"
              className="island-panel"
              role="dialog"
              aria-label="Your farm"
            >
              <div className="island-panel-header">
                <div>
                  <span className="eyebrow">Your farm · optional</span>
                </div>
                <button
                  className="island-close"
                  onClick={() => setOpenPanel(null)}
                  aria-label="Close panel"
                >
                  <X size={16} />
                </button>
              </div>

              {constraints.currentCrops.length > 0 && (
                <>
                  <div className="farm-section-heading">
                    <span>Your rotation</span>
                    <div className="indicator-actions">
                      <button onClick={() => setConstraints({ ...constraints, currentCrops: [] })}>Clear</button>
                    </div>
                  </div>
                  <div className="crop-chips">
                    {constraints.currentCrops.map((id, index) => (
                      <span key={`${id}-${index}`} className="crop-chip">
                        <span className="crop-chip-step">{index + 1}</span>
                        {CROP_BY_ID[id]?.emoji} {CROP_BY_ID[id]?.name ?? id}
                        <button type="button" aria-label="Remove crop" onClick={() => removeCrop(index)}>
                          <X size={12} />
                        </button>
                      </span>
                    ))}
                  </div>
                </>
              )}

              <div className="farm-section-heading">
                <span>Add crops</span>
              </div>
              <div className="priority-mini-grid farm-crop-grid">
                {SELECTABLE_CROPS.map((crop) => {
                  const inRotation = constraints.currentCrops.includes(crop.id);
                  const full = constraints.currentCrops.length >= 4;
                  return (
                    <button
                      key={crop.id}
                      className={inRotation ? "mini-priority active" : "mini-priority"}
                      onClick={() => addCrop(crop.id)}
                      disabled={full}
                      title={full ? "Rotation is full: remove a crop first" : `Add ${crop.name}`}
                    >
                      <span className="farm-crop-emoji" aria-hidden="true">{crop.emoji}</span>
                      {crop.name}
                    </button>
                  );
                })}
              </div>

              <div className="farm-section-heading">
                <span>Farm conditions</span>
              </div>
              <div className="priority-mini-grid">
                <button
                  className={constraints.irrigation ? "mini-priority active" : "mini-priority"}
                  onClick={() => setConstraints({ ...constraints, irrigation: !constraints.irrigation })}
                  aria-pressed={constraints.irrigation}
                >
                  <Droplets size={16} />
                  Irrigation available
                </button>
                <button
                  className={constraints.livestock ? "mini-priority active" : "mini-priority"}
                  onClick={() => setConstraints({ ...constraints, livestock: !constraints.livestock })}
                  aria-pressed={constraints.livestock}
                >
                  <Sprout size={16} />
                  Livestock / forage needed
                </button>
              </div>
            </section>
          )}

          <nav className="map-island" aria-label="Map controls">
            <button
              className={openPanel === "location" ? "island-icon-button active" : "island-icon-button"}
              onClick={() => togglePanel("location")}
              aria-expanded={openPanel === "location"}
              aria-controls="island-panel-location"
              aria-label="Find a location"
              title="Find a location"
            >
              <Search size={19} />
            </button>

            <button
              className={openPanel === "priorities" ? "island-icon-button active" : "island-icon-button"}
              onClick={() => togglePanel("priorities")}
              aria-expanded={openPanel === "priorities"}
              aria-controls="island-panel-priorities"
              aria-label="Farmer priorities"
              title="Farmer priorities"
            >
              <Sprout size={19} />
              {priorities.length > 0 && (
                <span className="island-badge">{priorities.length}</span>
              )}
            </button>

            <button
              className={openPanel === "indicators" ? "island-icon-button active" : "island-icon-button"}
              onClick={() => togglePanel("indicators")}
              aria-expanded={openPanel === "indicators"}
              aria-controls="island-panel-indicators"
              aria-label="Climate indicators"
              title="Climate indicators"
            >
              <CloudSun size={19} />
              {indicators.length > 0 && (
                <span className="island-badge">{indicators.length}</span>
              )}
            </button>

            <button
              className={openPanel === "farm" ? "island-icon-button active" : "island-icon-button"}
              onClick={() => togglePanel("farm")}
              aria-expanded={openPanel === "farm"}
              aria-controls="island-panel-farm"
              aria-label="Your farm"
              title="Your farm: current rotation, irrigation, livestock"
            >
              <Tractor size={19} />
              {(constraints.currentCrops.length > 0 || constraints.irrigation || constraints.livestock) && (
                <span className="island-badge">✓</span>
              )}
            </button>

            <span className="island-divider" aria-hidden="true" />

            <div
              className={field ? "island-status ready" : "island-status"}
              role="status"
              title={
                field
                  ? field.selectionType === "area"
                    ? `Field selected · ${displayArea}`
                    : `Point selected · ${field.latitude.toFixed(4)}°, ${field.longitude.toFixed(4)}°`
                  : "Nothing selected yet: click the map or draw a field"
              }
            >
              {field ? (
                field.selectionType === "area" ? <Square size={17} /> : <MapPin size={17} />
              ) : (
                <MousePointerClick size={17} />
              )}
              <span className="visually-hidden">
                {field ? "Selection ready" : "Nothing selected yet"}
              </span>
            </div>

            <div className="island-go-wrap">
              {showContinueHint && (
                <div className="island-continue-hint" role="status" onClick={() => setShowContinueHint(false)}>
                  Continue to analysis
                </div>
              )}
              <button
                className="island-go-button"
                disabled={!field}
                onClick={() => {
                  setShowContinueHint(false);
                  analyze();
                }}
                aria-label="Continue to analysis"
                title={field ? "Continue to analysis" : "Select a point or field first"}
              >
                {/* Same icon as "Analysis" in the top navigation: this button goes there. */}
                <BarChart3 size={19} />
              </button>
            </div>
          </nav>
        </div>
      </main>
    </div>
  );
}
